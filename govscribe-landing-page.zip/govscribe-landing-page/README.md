# GOVSCRIBE Landing Page

A responsive promotional landing page for the GOVSCRIBE QR Code File Tracking System.

## Publish with GitHub Pages
1. Create a public GitHub repository (for example, `govscribe-landing-page`).
2. Upload `index.html` and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish the site. The URL will be shown on the Pages settings screen.

Before publishing, replace `YOUR-EMAIL@example.com` in `index.html` with a real project contact email.

This is a promotional front-end prototype. The email CTA uses the visitor's email app; it does not store submissions in a database.
